package com.cs157a.PCBuilder.service;

import java.util.List;

import com.cs157a.PCBuilder.model.Case;

public interface CaseService {
	public List<Case> selectAll();
	public Case get(int caseId);
}
