package com.cs157a.PCBuilder.service;

import java.util.List;

import com.cs157a.PCBuilder.model.CPU;

public interface CPUService {
	public List<CPU> selectAll();
	public CPU get(int cpuId);
}
