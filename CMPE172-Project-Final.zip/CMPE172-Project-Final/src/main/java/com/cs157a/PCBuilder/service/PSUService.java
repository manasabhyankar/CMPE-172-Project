package com.cs157a.PCBuilder.service;

import java.util.List;

import com.cs157a.PCBuilder.model.PSU;

public interface PSUService {
	public List<PSU> selectAll();
	public PSU get(int gpuId);
}
